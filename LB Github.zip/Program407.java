
class node
{
    public int data;
    public node next;
}

class SinglyLL
{
    private node first;
    private int Count;
}




class Program407
{
    public static void main(String arg[])
    {
        SinglyLL obj = new SinglyLL();
    }
}
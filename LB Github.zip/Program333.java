import java.util.*;
import java.io.*;

class Program333
{
    public static void main(String arg[]) throws Exception
    {
        Scanner sobj = new Scanner(System.in);

        String str = "     Hello     ";

        System.out.println("Length of str is : "+str.length());

    }
}